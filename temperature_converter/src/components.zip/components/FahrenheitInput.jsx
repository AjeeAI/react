
function FahrenheitInput({ fahrenheit, onTypeFahrenheit }) {
  return (
    <div>
      <label>Fahrenheit: </label>
      <input 
        type="number" 
        value={fahrenheit} 
        onChange={onTypeFahrenheit} 
      />
    </div>
  );
}

export default FahrenheitInput;
